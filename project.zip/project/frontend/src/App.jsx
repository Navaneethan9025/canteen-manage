import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import signup from './signup'

function App() {

  return (
    <div>
        <signup/>
    </div>
  )
}

export default App
